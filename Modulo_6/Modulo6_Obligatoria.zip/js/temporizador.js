$(document).ready(function(){
    
    var array_contador = $("#box-minutos-cuenta").html();
    
    ///Aun no esta completo el jquery funcional para todo el temporizador.
    
    
    
});